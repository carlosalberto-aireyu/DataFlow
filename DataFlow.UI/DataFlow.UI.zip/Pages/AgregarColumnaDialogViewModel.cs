﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace DataFlow.UI.Pages
{
    public class AgregarColumnaDialogViewModel : INotifyPropertyChanged
    {
        private int _indexColumn;
        private string? _columnName;
        private string? _displayName;
        private string? _description;
        private string? _dataType;
        private string? _defaultValue;
        private string? _columnType;

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void Raise([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public int IndexColumn
        {
            get => _indexColumn;
            set
            {
                if (_indexColumn != value)
                {
                    _indexColumn = value;
                    Raise(nameof(IndexColumn));
                }
            }
        }
        public string? ColumnName
        {
            get => _columnName;
            set
            {
                if (_columnName != value)
                {
                    var oldValue = _columnName;
                    _columnName = value;
                    Raise(nameof(ColumnName));

                    if (string.IsNullOrWhiteSpace(_displayName) || _displayName == oldValue)
                    {
                        DisplayName = value;
                    }
                }
            }
        }

        public string? DisplayName
        {
            get => _displayName;
            set
            {
                if (_displayName != value)
                {
                    _displayName = value;
                    Raise(nameof(DisplayName));
                }
            }
        }

        public string? Description
        {
            get => _description;
            set
            {
                if (_description != value)
                {
                    _description = value;
                    Raise(nameof(Description));
                }
            }
        }

        public string? DataType
        {
            get => _dataType;
            set
            {
                if (_dataType != value)
                {
                    _dataType = value;
                    Raise(nameof(DataType));
                }
            }
        }

        public string? DefaultValue
        {
            get => _defaultValue;
            set
            {
                if (_defaultValue != value)
                {
                    _defaultValue = value;
                    Raise(nameof(DefaultValue));
                }
            }
        }

 
        public string? ColumnType
        {
            get => _columnType;
            set
            {
                if (_columnType != value)
                {
                    _columnType = value;
                    Raise(nameof(ColumnType));
                }
            }
        }
    }
}