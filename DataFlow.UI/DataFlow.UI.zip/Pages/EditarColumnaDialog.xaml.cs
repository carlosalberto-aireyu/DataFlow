﻿using DataFlow.UI.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace DataFlow.UI.Pages
{
    public partial class EditarColumnaDialog : Window
    {
        private readonly ConfigColumnItemViewModel _columnViewModel;

        public EditarColumnaDialog(ConfigColumnItemViewModel columnViewModel)
        {
            InitializeComponent();
            _columnViewModel = columnViewModel ?? throw new ArgumentNullException(nameof(columnViewModel));

            IndexColumnTextBox.Text = _columnViewModel.IndexColumn.ToString();

            NombreTextBox.Text = _columnViewModel.Name;
            DisplayNameTextBox.Text = _columnViewModel.NameDisplay;
            DescripcionTextBox.Text = _columnViewModel.Description;

            
            var dataTypeItems = DataTypeComboBox.Items;
            for (int i = 0; i < dataTypeItems.Count; i++)
            {
                if ((dataTypeItems[i] as ComboBoxItem)?.Content?.ToString() == _columnViewModel.DataType)
                {
                    DataTypeComboBox.SelectedIndex = i;
                    break;
                }
            }

            if (DataTypeComboBox.SelectedIndex == -1)
            {
                DataTypeComboBox.SelectedIndex = 0;
            }

            
            DefaultValueTextBox.Text = _columnViewModel.DefaultValue;

            
            var columnTypeItems = ColumnTypeComboBox.Items;
            for (int i = 0; i < columnTypeItems.Count; i++)
            {
                if ((columnTypeItems[i] as ComboBoxItem)?.Content?.ToString() == _columnViewModel.ColumnType)
                {
                    ColumnTypeComboBox.SelectedIndex = i;
                    break;
                }
            }

            if (ColumnTypeComboBox.SelectedIndex == -1)
            {
                ColumnTypeComboBox.SelectedIndex = 0;
            }
            NombreTextBox.Focus();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var indexColumnText = IndexColumnTextBox.Text?.Trim();
            var nombre = NombreTextBox.Text?.Trim();
            var displayName = DisplayNameTextBox.Text?.Trim();
            var dataType = (DataTypeComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString();
            var defaultValue = DefaultValueTextBox.Text?.Trim();
            var columnType = (ColumnTypeComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString();

            if(int.TryParse(indexColumnText, out int indexColumn))
            {
                if(indexColumn < 0)
                {
                    ErrorMessage.Text = "El índice de la columna debe ser un número entero no negativo.";
                    ErrorMessage.Visibility = Visibility.Visible;
                    IndexColumnTextBox.Focus();
                    return;
                }
            }
            else
            {
                ErrorMessage.Text = "El índice de la columna no es valido.";
                ErrorMessage.Visibility = Visibility.Visible;
                IndexColumnTextBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(nombre))
            {
                ErrorMessage.Text = "El nombre de la columna no puede estar vacío.";
                ErrorMessage.Visibility = Visibility.Visible;
                NombreTextBox.Focus();
                return;
            }

            if (nombre.Length < 2)
            {
                ErrorMessage.Text = "El nombre debe tener al menos 2 caracteres.";
                ErrorMessage.Visibility = Visibility.Visible;
                NombreTextBox.Focus();
                return;
            }

            _columnViewModel.IndexColumn = int.Parse(indexColumnText);
            _columnViewModel.Name = nombre;
            _columnViewModel.NameDisplay = displayName ?? nombre;
            _columnViewModel.DataType = dataType ?? "string";
            _columnViewModel.DefaultValue = defaultValue ?? string.Empty;
            _columnViewModel.ColumnType = columnType ?? string.Empty;
            _columnViewModel.Description = DescripcionTextBox.Text?.Trim();

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}