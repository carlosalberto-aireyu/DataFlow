﻿using System.Windows.Controls;

namespace DataFlow.UI.Pages
{
    /// <summary>
    /// Lógica de interacción para Historial.xaml
    /// </summary>
    public partial class Historial : Page
    {
        public Historial()
        {
            InitializeComponent();
        }
    }
}
