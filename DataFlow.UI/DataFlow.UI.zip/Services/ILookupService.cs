﻿using DataFlow.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataFlow.UI.Services
{
    public interface ILookupService
    {
        Task<IReadOnlyList<ColumnTypeLookup>> GetColumnTypesAsync<T>(CancellationToken cancellationToken = default);
        Task<IReadOnlyList<DataTypeLookup>> GetDataTypesAsync<T>(CancellationToken cancellationToken = default);
    }
}
