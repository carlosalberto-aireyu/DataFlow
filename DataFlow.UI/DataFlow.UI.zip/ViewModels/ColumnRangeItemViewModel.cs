﻿using DataFlow.Core.Models;
using System;
using System.ComponentModel;
using System.Text.RegularExpressions;

namespace DataFlow.UI.ViewModels
{
    public class ColumnRangeItemViewModel : INotifyPropertyChanged
    {
        private string? _rFrom;
        private string? _rTo;
        private string? _defaultValue;
        private DateTime _createdAt;
        private DateTime _updatedAt;
        private bool _isSelected;

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void Raise(string propertyName)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        public int Id { get; set; }
        public int ConfigColumnId { get; set; }

        public string? RFrom
        {
            get => _rFrom;
            set
            {
                if (_rFrom != value)
                {
                    _rFrom = value?.ToUpperInvariant();
                    Raise(nameof(RFrom));
                    Raise(nameof(IsValid));
                    Raise(nameof(ValidationMessage));
                }
            }
        }

        public string? RTo
        {
            get => _rTo;
            set
            {
                if (_rTo != value)
                {
                    _rTo = value?.ToUpperInvariant();
                    Raise(nameof(RTo));
                    Raise(nameof(IsValid));
                    Raise(nameof(ValidationMessage));
                }
            }
        }

        public string ? DefaultValue
        {
            get => _defaultValue;
            set
            {
                if (_defaultValue != value)
                {
                    _defaultValue = value;
                    Raise(nameof(DefaultValue));
                }
            }
        }

        public DateTime CreatedAt
        {
            get => _createdAt;
            set
            {
                if (_createdAt != value)
                {
                    _createdAt = value;
                    Raise(nameof(CreatedAt));
                    Raise(nameof(CreatedAtFormatted));
                }
            }
        }

        public DateTime UpdatedAt
        {
            get => _updatedAt;
            set
            {
                if (_updatedAt != value)
                {
                    _updatedAt = value;
                    Raise(nameof(UpdatedAt));
                    Raise(nameof(UpdatedAtFormatted));
                }
            }
        }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    Raise(nameof(IsSelected));
                }
            }
        }

        public bool IsValid =>
            !string.IsNullOrWhiteSpace(RFrom) && IsValidExcelCellAddress(RFrom) &&
            !string.IsNullOrWhiteSpace(RTo) && IsValidExcelCellAddress(RTo) &&
            IsRangeOrderCorrect;
        public bool IsNewRow => Id == 0;
        public string ValidationMessage
        {
            get
            {
                var messages = new List<string>();

                if (IsNewRow)
                {
                    if (string.IsNullOrWhiteSpace(RFrom) && string.IsNullOrWhiteSpace(RTo))
                        messages.Add("Complete ambos campos: 'Desde' y 'Hasta'.");
                    else if (string.IsNullOrWhiteSpace(RFrom))
                        messages.Add("El campo 'Desde' es requerido.");
                    else if (string.IsNullOrWhiteSpace(RTo))
                        messages.Add("El campo 'Hasta' es requerido.");
                }

                if (!string.IsNullOrWhiteSpace(RFrom) && !IsValidExcelCellAddress(RFrom))
                    messages.Add($"El formato de 'Desde' no es una dirección de celda de Excel válida (ej: A1, B25).");
                if (!string.IsNullOrWhiteSpace(RTo) && !IsValidExcelCellAddress(RTo))
                    messages.Add($"El formato de 'Hasta' no es una dirección de celda de Excel válida (ej: A1, B25).");
                if (IsValidExcelCellAddress(RFrom) && IsValidExcelCellAddress(RTo) && !IsRangeOrderCorrect)
                    messages.Add("El rango 'Hasta' no puede ser menor que el rango 'Desde' (ej: A10-A15 es correcto; A15-A10 es incorrecto; B1-A4 es incorrecto).");

                return messages.Any() ? string.Join(Environment.NewLine, messages) : string.Empty;
            }
        }

        public string CreatedAtFormatted => CreatedAt.ToString("dd/MM/yyyy HH:mm");
        public string UpdatedAtFormatted => UpdatedAt.ToString("dd/MM/yyyy HH:mm");
        public string DisplayName => $"{RFrom} - {RTo}";

        public ColumnRangeItemViewModel()
        {
            _createdAt = DateTime.MinValue;
            _updatedAt = DateTime.MinValue;
        }
        public ColumnRangeItemViewModel(
            int id,
            int configColumnId,
            string? rFrom,
            string? rTo,
            string? defaultValue,
            DateTime createdAt,
            DateTime updatedAt)
        {
            Id = id;
            ConfigColumnId = configColumnId;
            _defaultValue = defaultValue;
            _rFrom = rFrom;
            _rTo = rTo;
            _createdAt = createdAt;
            _updatedAt = updatedAt;
            _isSelected = false;
        }

        public static ColumnRangeItemViewModel FromModel(ColumnRange model)
        {
            return new ColumnRangeItemViewModel(
                model.Id,
                model.ConfigColumnId,
                model.RFrom,
                model.RTo,
                model.DefaultValue,
                model.CreatedAt,
                model.UpdatedAt);
        }

        public void UpdateFromModel(ColumnRange model)
        {
            Id = model.Id;
            ConfigColumnId = model.ConfigColumnId;
            DefaultValue = model.DefaultValue;
            RFrom = model.RFrom;
            RTo = model.RTo;
            CreatedAt = model.CreatedAt;
            UpdatedAt = model.UpdatedAt;
        }

        public override string ToString() => DisplayName;

        private bool IsValidExcelCellAddress(string? cellAddress)
        {
            if(string.IsNullOrWhiteSpace(cellAddress))
                return false;
            return Regex.IsMatch(cellAddress, @"^[A-Z]+[1-9][0-9]*$");
        }
        private (int columnNumber, int rowNumber)? ParseCellCoordinates(string? cellAddress)
        {
            if (string.IsNullOrWhiteSpace(cellAddress)) return null;

            Match match = Regex.Match(cellAddress, @"^([A-Z]+)([1-9][0-9]*)$");
            if (!match.Success) return null;

            string columnLetters = match.Groups[1].Value;
            int rowNumber = int.Parse(match.Groups[2].Value);

            int columnNumericalIndex = 0;
            for (int i = 0; i < columnLetters.Length; i++)
            {
                columnNumericalIndex = columnNumericalIndex * 26 + (columnLetters[i] - 'A' + 1);
            }

            return (columnNumericalIndex, rowNumber);
        }
        private int? CompareExcelCellAddresses(string? address1, string? address2)
        {
            if (string.IsNullOrWhiteSpace(address1) || string.IsNullOrWhiteSpace(address2)) return null;

            var coords1 = ParseCellCoordinates(address1);
            var coords2 = ParseCellCoordinates(address2);

            if (!coords1.HasValue || !coords2.HasValue) return null;

            if (coords1.Value.columnNumber < coords2.Value.columnNumber) return -1;
            if (coords1.Value.columnNumber > coords2.Value.columnNumber) return 1;

            if (coords1.Value.rowNumber < coords2.Value.rowNumber) return -1;
            if (coords1.Value.rowNumber > coords2.Value.rowNumber) return 1;

            return 0;
        }

        public bool IsRangeOrderCorrect
        {
            get
            {
                if (!IsValidExcelCellAddress(RFrom) || !IsValidExcelCellAddress(RTo))
                {
                    return true; 
                }

                int? comparison = CompareExcelCellAddresses(RFrom, RTo);
                return comparison.HasValue && comparison.Value <= 0;
            }
        }

    }
}